/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { Card, CardSuit, CardValue, Room, Player, TablePair, GameState } from './src/types.js';

const app = express();
const PORT = 3005; // Note: Internal app server port, Vite or dev runner will route this or we bind to PORT 3000

app.use(express.json());

// In-memory Room storage
interface ServerRoom extends Room {
  serverDeck: Card[];
  lastActivity: number;
}
const rooms = new Map<string, ServerRoom>();

// Clean up stale inactive rooms (inactive for > 2 hours)
setInterval(() => {
  const now = Date.now();
  for (const [roomId, room] of rooms.entries()) {
    if (now - room.lastActivity > 2 * 60 * 60 * 1000) {
      rooms.delete(roomId);
    }
  }
}, 15 * 60 * 1000);

// Helper constants for cards
const SUITS: CardSuit[] = ['H', 'D', 'C', 'S'];
const VALUES: { value: CardValue; rank: number }[] = [
  { value: '6', rank: 6 },
  { value: '7', rank: 7 },
  { value: '8', rank: 8 },
  { value: '9', rank: 9 },
  { value: '10', rank: 10 },
  { value: 'J', rank: 11 },
  { value: 'Q', rank: 12 },
  { value: 'K', rank: 13 },
  { value: 'A', rank: 14 }
];

function createDeck(): Card[] {
  const deck: Card[] = [];
  for (const s of SUITS) {
    for (const v of VALUES) {
      deck.push({
        id: `${s}_${v.value}`,
        suit: s,
        value: v.value,
        rank: v.rank
      });
    }
  }
  return deck;
}

function shuffle(deck: Card[]): Card[] {
  const newDeck = [...deck];
  for (let i = newDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
  }
  return newDeck;
}

function cardToString(card: Card): string {
  const suitsRu: Record<CardSuit, string> = { H: '♥', D: '♦', C: '♣', S: '♠' };
  return `${card.value}${suitsRu[card.suit]}`;
}

function suitToName(suit: CardSuit): string {
  const suitsRu: Record<CardSuit, string> = {
    H: 'Черви ♥',
    D: 'Бубны ♦',
    C: 'Трефы ♣',
    S: 'Пики ♠'
  };
  return suitsRu[suit];
}

// Helper to fill hands up to 6 cards
function refillHands(room: ServerRoom) {
  const game = room.game;
  if (!game) return;

  const deck = room.serverDeck;
  const players = room.players;

  const attacker = players.find(p => p.id === game.attackerId);
  const defender = players.find(p => p.id === game.defenderId);

  if (!attacker || !defender) return;

  // Attacker draws first
  while (attacker.hand && attacker.hand.length < 6 && deck.length > 0) {
    attacker.hand.push(deck.shift()!);
  }
  attacker.cardsCount = attacker.hand ? attacker.hand.length : 0;

  // Defender draws second
  while (defender.hand && defender.hand.length < 6 && deck.length > 0) {
    defender.hand.push(deck.shift()!);
  }
  defender.cardsCount = defender.hand ? defender.hand.length : 0;

  game.deckCount = deck.length;
}

// Helper to check if game is finished
function checkGameOver(room: ServerRoom) {
  const game = room.game;
  if (!game || game.status !== 'playing') return;

  const p1 = room.players[0];
  const p2 = room.players[1];

  if (game.deckCount === 0) {
    const p1Empty = !p1.hand || p1.hand.length === 0;
    const p2Empty = !p2.hand || p2.hand.length === 0;

    if (p1Empty && p2Empty) {
      game.status = 'finished';
      game.winnerId = null;
      game.loserId = null;
      game.isDraw = true;
      game.lastActionMessage = 'Игра окончена! Ничья — у обоих игроков закончились карты.';
      room.chat.push({
        id: Math.random().toString(),
        senderId: 'system',
        senderName: 'Система',
        text: 'Игра окончена вничью!',
        timestamp: Date.now(),
        isSystem: true
      });
    } else if (p1Empty) {
      game.status = 'finished';
      game.winnerId = p1.id;
      game.loserId = p2.id;
      game.isDraw = false;
      game.lastActionMessage = `Игра окончена! Игрок ${p1.name} избавился от карт. ${p2.name} остался в дураках!`;
      room.chat.push({
        id: Math.random().toString(),
        senderId: 'system',
        senderName: 'Система',
        text: `Игрок ${p1.name} победил! ${p2.name} остался в дураках.`,
        timestamp: Date.now(),
        isSystem: true
      });
    } else if (p2Empty) {
      game.status = 'finished';
      game.winnerId = p2.id;
      game.loserId = p1.id;
      game.isDraw = false;
      game.lastActionMessage = `Игра окончена! Игрок ${p2.name} избавился от карт. ${p1.name} остался в дураках!`;
      room.chat.push({
        id: Math.random().toString(),
        senderId: 'system',
        senderName: 'Система',
        text: `Игрок ${p2.name} победил! ${p1.name} остался в дураках.`,
        timestamp: Date.now(),
        isSystem: true
      });
    }
  }
}

// Helper to start game
function startGame(room: ServerRoom) {
  const deck = shuffle(createDeck());

  const p1 = room.players[0];
  const p2 = room.players[1];

  p1.hand = [];
  p2.hand = [];

  // Deal 6 cards to each
  for (let i = 0; i < 6; i++) {
    if (deck.length > 0) p1.hand.push(deck.shift()!);
    if (deck.length > 0) p2.hand.push(deck.shift()!);
  }

  p1.cardsCount = p1.hand.length;
  p2.cardsCount = p2.hand.length;
  p1.isReady = true;
  p2.isReady = true;

  // Let bottom card be trump
  let trumpCard: Card | null = null;
  let trumpSuit: CardSuit = 'H';
  if (deck.length > 0) {
    trumpCard = deck[deck.length - 1]; // bottom card
    trumpSuit = trumpCard.suit;
  }

  // Find lowest trump rank to decide starting attacker
  let p1MinTrumpRank = 99;
  let p2MinTrumpRank = 99;

  for (const c of p1.hand) {
    if (c.suit === trumpSuit && c.rank < p1MinTrumpRank) {
      p1MinTrumpRank = c.rank;
    }
  }
  for (const c of p2.hand) {
    if (c.suit === trumpSuit && c.rank < p2MinTrumpRank) {
      p2MinTrumpRank = c.rank;
    }
  }

  let attackerId = p1.id;
  let defenderId = p2.id;
  let startMsgText = '';

  if (p1MinTrumpRank < 99 || p2MinTrumpRank < 99) {
    if (p1MinTrumpRank < p2MinTrumpRank) {
      attackerId = p1.id;
      defenderId = p2.id;
      const minCard = p1.hand.find(c => c.suit === trumpSuit && c.rank === p1MinTrumpRank);
      startMsgText = `Первым ходит ${p1.name}, у него меньший козырь (${minCard ? cardToString(minCard) : ''})`;
    } else {
      attackerId = p2.id;
      defenderId = p1.id;
      const minCard = p2.hand.find(c => c.suit === trumpSuit && c.rank === p2MinTrumpRank);
      startMsgText = `Первым ходит ${p2.name}, у него меньший козырь (${minCard ? cardToString(minCard) : ''})`;
    }
  } else {
    // If no one holds a trump
    attackerId = p1.id;
    defenderId = p2.id;
    startMsgText = `Ни у кого нет козырей в руках. Ходит первый подключившийся: ${p1.name}`;
  }

  room.game = {
    status: 'playing',
    deckCount: deck.length,
    trumpCard,
    trumpSuit,
    attackerId,
    defenderId,
    table: [],
    discardPileCount: 0,
    winnerId: null,
    loserId: null,
    isDraw: false,
    lastActionMessage: 'Раздача завершена! Игра началась.'
  };

  room.serverDeck = deck;

  room.chat.push({
    id: `sys-${Date.now()}`,
    senderId: 'system',
    senderName: 'Система',
    text: `Игра началась! Козырь — ${suitToName(trumpSuit)}. ${startMsgText}`,
    timestamp: Date.now(),
    isSystem: true
  });
}

// --------------------------------------------------
// API ENDPOINTS
// --------------------------------------------------

// Create room
app.post('/api/room/create', (req, res) => {
  const { playerName } = req.body;
  if (!playerName || typeof playerName !== 'string') {
    return res.status(400).json({ error: 'Имя игрока обязательно' });
  }

  // Generate unique room ID
  let roomId = '';
  do {
    roomId = Math.random().toString(36).substring(2, 7).toUpperCase();
  } while (rooms.has(roomId));

  const playerId = 'p-' + Math.random().toString(36).substring(2, 9);

  const newRoom: ServerRoom = {
    id: roomId,
    players: [
      {
        id: playerId,
        name: playerName.trim(),
        isReady: false,
        cardsCount: 0,
        isOnline: true,
        hand: []
      }
    ],
    game: null,
    chat: [
      {
        id: 'sys-init',
        senderId: 'system',
        senderName: 'Система',
        text: `Комната ${roomId} создана игроком ${playerName}. Поделитесь кодом с другом для игры онлайн.`,
        timestamp: Date.now(),
        isSystem: true
      }
    ],
    serverDeck: [],
    createdAt: Date.now(),
    lastActivity: Date.now()
  };

  rooms.set(roomId, newRoom);
  res.json({ roomId, playerId, playerName });
});

// Join room
app.post('/api/room/join', (req, res) => {
  const { roomId, playerName } = req.body;
  if (!roomId || !playerName) {
    return res.status(400).json({ error: 'Код комнаты и Имя игрока обязательны' });
  }

  const cleanRoomId = roomId.trim().toUpperCase();
  const room = rooms.get(cleanRoomId);

  if (!room) {
    return res.status(404).json({ error: 'Комната с таким кодом не найдена' });
  }

  room.lastActivity = Date.now();

  // If player with same name already exists in room, reconnect them
  const existingPlayer = room.players.find(p => p.name.toLowerCase() === playerName.trim().toLowerCase());
  if (existingPlayer) {
    existingPlayer.isOnline = true;
    return res.json({ roomId: cleanRoomId, playerId: existingPlayer.id, playerName: existingPlayer.name });
  }

  if (room.players.length >= 2) {
    return res.status(400).json({ error: 'Комната уже заполнена (максимум 2 игрока)' });
  }

  const playerId = 'p-' + Math.random().toString(36).substring(2, 9);
  const newPlayer: Player = {
    id: playerId,
    name: playerName.trim(),
    isReady: false,
    cardsCount: 0,
    isOnline: true,
    hand: []
  };

  room.players.push(newPlayer);
  room.chat.push({
    id: `sys-join-${Date.now()}`,
    senderId: 'system',
    senderName: 'Система',
    text: `Игрок ${newPlayer.name} присоединился к комнате!`,
    timestamp: Date.now(),
    isSystem: true
  });

  res.json({ roomId: cleanRoomId, playerId, playerName: newPlayer.name });
});

// Get room status (masked for player)
app.get('/api/room/:roomId', (req, res) => {
  const { roomId } = req.params;
  const { playerId } = req.query;

  const room = rooms.get(roomId.toUpperCase());
  if (!room) {
    return res.status(404).json({ error: 'Комната не найдена' });
  }

  room.lastActivity = Date.now();

  // Mask other player's hand for security
  const maskedPlayers = room.players.map(p => {
    if (p.id === playerId) {
      return {
        ...p,
        cardsCount: p.hand ? p.hand.length : 0
      };
    } else {
      // Mask hand!
      const { hand, ...rest } = p;
      return {
        ...rest,
        cardsCount: hand ? hand.length : 0
      };
    }
  });

  res.json({
    id: room.id,
    players: maskedPlayers,
    game: room.game,
    chat: room.chat,
    createdAt: room.createdAt
  });
});

// Toggle Ready State
app.post('/api/room/:roomId/ready', (req, res) => {
  const { roomId } = req.params;
  const { playerId } = req.body;

  const room = rooms.get(roomId.toUpperCase());
  if (!room) {
    return res.status(404).json({ error: 'Комната не найдена' });
  }

  room.lastActivity = Date.now();
  const player = room.players.find(p => p.id === playerId);
  if (!player) {
    return res.status(404).json({ error: 'Игрок не найден в комнате' });
  }

  player.isReady = !player.isReady;

  room.chat.push({
    id: `sys-ready-${Date.now()}`,
    senderId: 'system',
    senderName: 'Система',
    text: `Игрок ${player.name} ${player.isReady ? 'готов к игре!' : 'снял готовность.'}`,
    timestamp: Date.now(),
    isSystem: true
  });

  // Automatically start if 2 players are both ready
  if (room.players.length === 2 && room.players.every(p => p.isReady)) {
    startGame(room);
  }

  res.json({ success: true, isReady: player.isReady });
});

// Post Chat message or predefined emote
app.post('/api/room/:roomId/chat', (req, res) => {
  const { roomId } = req.params;
  const { playerId, text } = req.body;

  const room = rooms.get(roomId.toUpperCase());
  if (!room) {
    return res.status(404).json({ error: 'Комната не найдена' });
  }

  room.lastActivity = Date.now();
  const player = room.players.find(p => p.id === playerId);
  if (!player) {
    return res.status(404).json({ error: 'Игрок не найден в комнате' });
  }

  const newMessage = {
    id: 'msg-' + Math.random().toString(36).substring(2, 9),
    senderId: player.id,
    senderName: player.name,
    text: text.trim(),
    timestamp: Date.now()
  };

  room.chat.push(newMessage);
  res.json({ success: true, message: newMessage });
});

// Execute card action (attack, defend, take, pass)
app.post('/api/room/:roomId/action', (req, res) => {
  const { roomId } = req.params;
  const { playerId, actionType, cardId, targetPairId } = req.body;

  const room = rooms.get(roomId.toUpperCase());
  if (!room) {
    return res.status(404).json({ error: 'Комната не найдена' });
  }

  room.lastActivity = Date.now();
  const game = room.game;
  if (!game) {
    return res.status(400).json({ error: 'Игра не началась' });
  }

  if (game.status !== 'playing') {
    return res.status(400).json({ error: 'Игра уже завершена' });
  }

  const activePlayer = room.players.find(p => p.id === playerId);
  if (!activePlayer) {
    return res.status(403).json({ error: 'Вы не являетесь игроком в этой комнате' });
  }

  const partner = room.players.find(p => p.id !== playerId);

  if (actionType === 'attack') {
    if (playerId !== game.attackerId) {
      return res.status(400).json({ error: 'Вы не являетесь атакующим в этом раунде' });
    }
    if (!cardId) {
      return res.status(400).json({ error: 'Укажите карту для совершения хода' });
    }

    const card = activePlayer.hand?.find(c => c.id === cardId);
    if (!card) {
      return res.status(400).json({ error: 'Указанная карта не найдена в вашей руке' });
    }

    const defender = room.players.find(p => p.id === game.defenderId)!;
    const table = game.table;

    // Rule: max 6 cards on table
    if (table.length >= 6) {
      return res.status(400).json({ error: 'Достигнут лимит карт на столе (максимум 6 пар)' });
    }

    // Rule: Cannot attack with more cards than the defender has in hand currently, taking into account undefended cards.
    const undefendedCount = table.filter(t => !t.defenseCard).length;
    if (undefendedCount + 1 > defender.cardsCount) {
      return res.status(400).json({ error: 'Нельзя подкинуть карт больше, чем есть на руках у защищающегося' });
    }

    // Rule: Ranks on table must match
    if (table.length > 0) {
      const allowedRanks = new Set<CardValue>();
      for (const pair of table) {
        allowedRanks.add(pair.attackCard.value);
        if (pair.defenseCard) {
          allowedRanks.add(pair.defenseCard.value);
        }
      }

      if (!allowedRanks.has(card.value)) {
        return res.status(400).json({ error: 'Вы можете подбрасывать только те карты достоинств, которые уже лежат на столе!' });
      }
    }

    // Process Attack
    activePlayer.hand = activePlayer.hand?.filter(c => c.id !== cardId);
    activePlayer.cardsCount = activePlayer.hand ? activePlayer.hand.length : 0;

    table.push({
      id: card.id,
      attackCard: card
    });

    game.lastActionMessage = `Ход: ${activePlayer.name} сходил ${cardToString(card)}`;
    room.chat.push({
      id: `sys-attack-${Date.now()}`,
      senderId: 'system',
      senderName: 'Система',
      text: `${activePlayer.name} ходит: ${cardToString(card)}`,
      timestamp: Date.now(),
      isSystem: true
    });

  } else if (actionType === 'defend') {
    if (playerId !== game.defenderId) {
      return res.status(400).json({ error: 'Сейчас не ваша очередь отбиваться' });
    }
    if (!cardId || !targetPairId) {
      return res.status(400).json({ error: 'Выберите карту для отбивания и цель' });
    }

    const defenseCard = activePlayer.hand?.find(c => c.id === cardId);
    if (!defenseCard) {
      return res.status(400).json({ error: 'Выбранная карта не найдена у вас в руке' });
    }

    const pair = game.table.find(p => p.id === targetPairId);
    if (!pair) {
      return res.status(400).json({ error: 'Конкретное нападение для отбивания не найдено' });
    }
    if (pair.defenseCard) {
      return res.status(400).json({ error: 'Эта карта на столе уже отбита' });
    }

    // Verification of matching rules
    const attackCard = pair.attackCard;
    const ts = game.trumpSuit;
    let beats = false;

    if (defenseCard.suit === ts && attackCard.suit !== ts) {
      beats = true;
    } else if (defenseCard.suit === attackCard.suit && defenseCard.rank > attackCard.rank) {
      beats = true;
    } else if (defenseCard.suit === ts && attackCard.suit === ts && defenseCard.rank > attackCard.rank) {
      beats = true;
    }

    if (!beats) {
      return res.status(400).json({ error: 'Ваша карта не бьет карту нападения' });
    }

    // Process Defense
    activePlayer.hand = activePlayer.hand?.filter(c => c.id !== cardId);
    activePlayer.cardsCount = activePlayer.hand ? activePlayer.hand.length : 0;

    pair.defenseCard = defenseCard;

    game.lastActionMessage = `Защита: ${activePlayer.name} побил ${cardToString(attackCard)} картой ${cardToString(defenseCard)}`;
    room.chat.push({
      id: `sys-defend-${Date.now()}`,
      senderId: 'system',
      senderName: 'Система',
      text: `${activePlayer.name} отбил ${cardToString(attackCard)} картой ${cardToString(defenseCard)}`,
      timestamp: Date.now(),
      isSystem: true
    });

  } else if (actionType === 'take') {
    if (playerId !== game.defenderId) {
      return res.status(400).json({ error: 'Только защищающийся игрок может забрать карты' });
    }
    if (game.table.length === 0) {
      return res.status(400).json({ error: 'На столе нет карт для взятия' });
    }

    // Collect all cards from table
    const collectedCards: Card[] = [];
    for (const pair of game.table) {
      collectedCards.push(pair.attackCard);
      if (pair.defenseCard) {
        collectedCards.push(pair.defenseCard);
      }
    }

    activePlayer.hand?.push(...collectedCards);
    activePlayer.cardsCount = activePlayer.hand ? activePlayer.hand.length : 0;

    // Clear table
    game.table = [];

    // Refill hands from server deck
    refillHands(room);

    // Check game over
    checkGameOver(room);

    game.lastActionMessage = `Взял: ${activePlayer.name} забрал все карты со стола (${collectedCards.length} шт.)`;
    room.chat.push({
      id: `sys-take-${Date.now()}`,
      senderId: 'system',
      senderName: 'Система',
      text: `${activePlayer.name} сдался и взял все карты (${collectedCards.length} шт.)`,
      timestamp: Date.now(),
      isSystem: true
    });

    // Attacker remains the same, next attacking round starts! Since defender had to take cards, they skip.

  } else if (actionType === 'pass') {
    if (playerId !== game.attackerId) {
      return res.status(400).json({ error: 'Только атакующий может сделать Биту' });
    }
    if (game.table.length === 0) {
      return res.status(400).json({ error: 'На столе пусто, нечего отправлять в Бито' });
    }

    // Verify all cards are covered
    const allCovered = game.table.every(p => p.defenseCard !== undefined);
    if (!allCovered) {
      return res.status(400).json({ error: 'Нельзя объявить Биту — на столе остались не отбитые карты!' });
    }

    // Clear table to discard pile
    const discardCount = game.table.length * 2;
    game.discardPileCount += discardCount;
    game.table = [];

    // Refill hands
    refillHands(room);

    // Check game over
    checkGameOver(room);

    // Shift attack to Defender since defense was successful
    if (game.status === 'playing') {
      const currentAttacker = game.attackerId;
      const currentDefender = game.defenderId;
      game.attackerId = currentDefender;
      game.defenderId = currentAttacker;

      const nextAttackingPlayer = room.players.find(p => p.id === game.attackerId)!;
      game.lastActionMessage = `Бита! Ход переходит к ${nextAttackingPlayer.name}`;
      room.chat.push({
        id: `sys-pass-${Date.now()}`,
        senderId: 'system',
        senderName: 'Система',
        text: `Бита! Ход переходит к ${nextAttackingPlayer.name}`,
        timestamp: Date.now(),
        isSystem: true
      });
    }

  } else {
    return res.status(400).json({ error: 'Неизвестное действие' });
  }

  res.json({ success: true, game: game });
});

// Leave room
app.post('/api/room/:roomId/leave', (req, res) => {
  const { roomId } = req.params;
  const { playerId } = req.body;

  const room = rooms.get(roomId.toUpperCase());
  if (room) {
    room.lastActivity = Date.now();
    const leavingPlayer = room.players.find(p => p.id === playerId);
    if (leavingPlayer) {
      room.chat.push({
        id: `sys-leave-${Date.now()}`,
        senderId: 'system',
        senderName: 'Система',
        text: `Игрок ${leavingPlayer.name} покинул комнату.`,
        timestamp: Date.now(),
        isSystem: true
      });
    }

    room.players = room.players.filter(p => p.id !== playerId);
    if (room.players.length === 0) {
      rooms.delete(roomId.toUpperCase());
    } else {
      // If active game, abort it and finish
      if (room.game && room.game.status === 'playing') {
        room.game.status = 'finished';
        room.game.lastActionMessage = 'Второй игрок покинул комнату. Игра прервана.';
      }
    }
  }
  res.json({ success: true });
});

// --------------------------------------------------
// ASYNC BOOTSTRAP TO BIND TO PORT 3000
// --------------------------------------------------
async function startServer() {
  // Vite or Static serving middleware
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // PORT must be 3000 as per environmental constraints
  app.listen(3000, '0.0.0.0', () => {
    console.log(`Server running on port 3000`);
  });
}

startServer().catch((err) => {
  console.error("Critical error starting sever", err);
});
