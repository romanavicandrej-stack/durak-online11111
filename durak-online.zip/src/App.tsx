/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Users, 
  Copy, 
  Check, 
  Send, 
  ArrowLeft, 
  HelpCircle, 
  Volume2, 
  LogOut, 
  Play, 
  MessageSquare,
  Sparkles,
  RefreshCw,
  Trophy,
  AlertTriangle
} from 'lucide-react';
import { Card, CardSuit, CardValue, TablePair, Player, GameState, ChatMessage, Room } from './types.js';
import CardUnit from './components/CardUnit.js';

export default function App() {
  // Client and identity state
  const [playerName, setPlayerName] = useState<string>(() => {
    return localStorage.getItem('durak_player_name') || '';
  });
  const [roomId, setRoomId] = useState<string>(() => {
    return localStorage.getItem('durak_room_id') || '';
  });
  const [playerId, setPlayerId] = useState<string>(() => {
    return localStorage.getItem('durak_player_id') || '';
  });

  // Navigation and operational states
  const [roomInput, setRoomInput] = useState<string>('');
  const [isJoinActive, setIsJoinActive] = useState<boolean>(false);
  const [localRoom, setLocalRoom] = useState<Room | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorText, setErrorText] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Active turn choice helper state
  const [selectedMyCardId, setSelectedMyCardId] = useState<string | null>(null);
  const [gameErrorMessage, setGameErrorMessage] = useState<string>('');

  // UI state
  const [chatText, setChatText] = useState<string>('');
  const [showRules, setShowRules] = useState<boolean>(false);

  // Refs for auto-scroll
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Quick phrases list for social play
  const QUICK_PHRASES = [
    '👋 Привет!',
    '😂 Хех, неплохо!',
    '🤔 Ого, сильный ход...',
    '⏱️ Ходи скорей!',
    '🤪 Ну ты и Дурак!',
    '😎 У меня одни козыри!',
    '😱 Ой-ой-ой!',
    '🫡 Хорошая игра!'
  ];

  // Map card suit to display icon
  const suitIcons: Record<CardSuit, string> = {
    H: '♥', // Hearts
    D: '♦', // Diamonds
    C: '♣', // Clubs
    S: '♠'  // Spades
  };

  const suitNamesRu: Record<CardSuit, string> = {
    H: 'Черви ♥',
    D: 'Бубны ♦',
    C: 'Трефы ♣',
    S: 'Пики ♠'
  };

  // Inspect URL query params for "?room=CODE" to auto-route joining
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlRoomCode = params.get('room');
    if (urlRoomCode) {
      setRoomInput(urlRoomCode.toUpperCase());
      setIsJoinActive(true);
    }
  }, []);

  // Fetch updates from server once per second when in a room
  useEffect(() => {
    if (!roomId) return;

    // Run first fetch immediately
    fetchRoomState();

    const interval = setInterval(() => {
      fetchRoomState();
    }, 1000);

    return () => clearInterval(interval);
  }, [roomId, playerId]);

  // Scroll to bottom of chat when new message arrives
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [localRoom?.chat]);

  // Query room data from the full-stack server
  const fetchRoomState = async () => {
    if (!roomId) return;
    try {
      const res = await fetch(`/api/room/${roomId}?playerId=${playerId}`);
      if (res.ok) {
        const data = await res.json();
        setLocalRoom(data);
        setErrorText('');
      } else {
        // If room is not found, clear state so player can re-join
        if (res.status === 404) {
          handleLeave(false);
          setErrorText('Ваша комната была закрыта или время активности истекло.');
        }
      }
    } catch (err) {
      console.error('Ошибка в получении статуса комнаты', err);
    }
  };

  // Save Name and Identity to Local Storage
  const persistIdentity = (pId: string, rId: string, pName: string) => {
    localStorage.setItem('durak_player_id', pId);
    localStorage.setItem('durak_room_id', rId);
    localStorage.setItem('durak_player_name', pName);
    setPlayerId(pId);
    setRoomId(rId);
    setPlayerName(pName);
  };

  // Create game Room
  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) {
      setErrorText('Пожалуйста, введите ваше имя');
      return;
    }
    setIsLoading(true);
    setErrorText('');

    try {
      const res = await fetch('/api/room/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ playerName: playerName.trim() }),
      });

      const data = await res.json();
      if (res.ok) {
        persistIdentity(data.playerId, data.roomId, data.playerName);
        setRoomInput('');
      } else {
        setErrorText(data.error || 'Не удалось создать комнату.');
      }
    } catch (err) {
      setErrorText('Не удалось связаться с сервером. Попробуйте еще раз.');
    } finally {
      setIsLoading(false);
    }
  };

  // Join existing Room code
  const handleJoinRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) {
      setErrorText('Пожалуйста, введите ваше имя');
      return;
    }
    if (!roomInput.trim()) {
      setErrorText('Введите код комнаты');
      return;
    }
    setIsLoading(true);
    setErrorText('');

    try {
      const res = await fetch('/api/room/join', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          roomId: roomInput.trim().toUpperCase(), 
          playerName: playerName.trim() 
        }),
      });

      const data = await res.json();
      if (res.ok) {
        persistIdentity(data.playerId, data.roomId, data.playerName);
      } else {
        setErrorText(data.error || 'Не удалось присоединиться.');
      }
    } catch (err) {
      setErrorText('Комната не существует либо сервер перегружен.');
    } finally {
      setIsLoading(false);
    }
  };

  // Ready Up and Launch Deal
  const handleReadyToggle = async () => {
    if (!roomId || !playerId) return;
    try {
      const res = await fetch(`/api/room/${roomId}/ready`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ playerId }),
      });
      if (res.ok) {
        fetchRoomState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Send message chat or preset word
  const handleSendChatMessage = async (text: string) => {
    if (!text.trim() || !roomId || !playerId) return;
    try {
      const res = await fetch(`/api/room/${roomId}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ playerId, text }),
      });
      if (res.ok) {
        setChatText('');
        fetchRoomState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Submit Game round cards (Attack or defense)
  const submitGameAction = async (
    actionType: 'attack' | 'defend' | 'take' | 'pass', 
    cardId?: string, 
    targetPairId?: string
  ) => {
    if (!roomId || !playerId) return;
    setGameErrorMessage('');
    try {
      const res = await fetch(`/api/room/${roomId}/action`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          playerId, 
          actionType, 
          cardId, 
          targetPairId 
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setSelectedMyCardId(null);
        fetchRoomState();
      } else {
        setGameErrorMessage(data.error || 'Запрещенный правилами ход');
        // Clear error after 4 seconds automatically
        setTimeout(() => setGameErrorMessage(''), 4500);
      }
    } catch (err) {
      console.error(err);
      setGameErrorMessage('Ошибка связи с сервером.');
    }
  };

  // Handle clicking on my cards
  const handleMyCardClick = (card: Card, isAttacker: boolean) => {
    if (isAttacker) {
      // If I am attacker, clicking an eligible card attacks immediately
      submitGameAction('attack', card.id);
    } else {
      // If I am defender, clicking a card selects it as potential choice
      setSelectedMyCardId((prev) => (prev === card.id ? null : card.id));
    }
  };

  // Handle clicking on undefended cards on table
  const handleTablePairClick = (pair: TablePair) => {
    // If I select a card in my hand, and click this undefended attack card, attempt defense beat
    if (selectedMyCardId && !pair.defenseCard) {
      submitGameAction('defend', selectedMyCardId, pair.id);
    }
  };

  // Quit and Leave Room session
  const handleLeave = async (callServer: boolean = true) => {
    if (callServer && roomId && playerId) {
      try {
        await fetch(`/api/room/${roomId}/leave`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ playerId }),
        });
      } catch (err) {
        console.error(err);
      }
    }

    // Reset local identity credentials
    localStorage.removeItem('durak_room_id');
    localStorage.removeItem('durak_player_id');
    setRoomId('');
    setLocalRoom(null);
    setSelectedMyCardId(null);
    setGameErrorMessage('');
    // Remove query parameter from URL completely to return to fresh state
    if (window.history.pushState) {
      const newurl = window.location.protocol + "//" + window.location.host + window.location.pathname;
      window.history.pushState({ path: newurl }, '', newurl);
    }
  };

  // Copy share Link
  const copyShareLink = () => {
    const link = `${window.location.origin}?room=${roomId}`;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Copy room Code
  const copyRoomCode = () => {
    navigator.clipboard.writeText(roomId);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Quick state parsing helpers
  const me = localRoom?.players.find(p => p.id === playerId);
  const companion = localRoom?.players.find(p => p.id !== playerId);
  const game = localRoom?.game;

  const isMyTurn = game ? (game.attackerId === playerId) : false;
  const isMyDefending = game ? (game.defenderId === playerId) : false;

  // Let's identify who is the attacker and defender naming strings
  const attackerName = localRoom?.players.find(p => p.id === game?.attackerId)?.name || 'Атакующий';
  const defenderName = localRoom?.players.find(p => p.id === game?.defenderId)?.name || 'Защищающийся';

  return (
    <div className="min-h-screen bg-[#07130c] text-white font-sans flex flex-col justify-between relative overflow-hidden">
      {/* Background Atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#14402a_0%,_#06140d_100%)] pointer-events-none"></div>
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

      {/* HEADER BAR */}
      <header className="relative z-20 border-b border-white/5 bg-black/30 px-4 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.45)] font-mono text-xl font-black text-slate-950 select-none">
              Д
            </div>
            <div>
              <h1 className="text-sm sm:text-xl font-black tracking-tight uppercase text-white flex items-center gap-1">
                Durak Online
              </h1>
              <p className="text-[9px] sm:text-[10px] text-emerald-400 font-mono tracking-widest uppercase">Professional League</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {roomId && (
              <div className="hidden md:flex flex-col text-right mr-3">
                <div className="text-[9px] text-white/40 uppercase tracking-widest">Статус комнаты</div>
                <div className="text-xs font-mono text-emerald-400 font-semibold uppercase">
                  {localRoom?.game ? (localRoom.game.status === 'playing' ? 'ИДЕТ ДУЭЛЬ' : 'ИГРА ОКОНЧЕНА') : 'ОЖИДАНИЕ ИГРОКА'}
                </div>
              </div>
            )}

            <button
              onClick={() => setShowRules(!showRules)}
              className="flex items-center gap-1.5 text-xs font-semibold text-white/80 hover:text-white px-4 py-2 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
            >
              <HelpCircle size={14} />
              <span className="hidden sm:inline">Правила</span>
            </button>

            {roomId && (
              <button
                onClick={() => handleLeave(true)}
                className="flex items-center gap-1.5 text-xs font-bold text-rose-300 bg-rose-600/10 hover:bg-rose-600/20 border border-rose-500/20 hover:border-rose-500/40 px-4 py-2 rounded-full transition-all cursor-pointer"
              >
                <LogOut size={13} className="text-rose-400" />
                <span className="hidden sm:inline">Выйти</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* RULES PANEL DROPDOWN */}
      <AnimatePresence>
        {showRules && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="border-b border-yellow-800/30 bg-amber-500/5 px-4 py-4 text-slate-300 text-xs sm:text-sm relative z-20"
          >
            <div className="mx-auto max-w-3xl">
              <h3 className="font-bold text-amber-400 text-sm mb-2 flex items-center gap-1.5">
                <Sparkles size={16} /> Правила игры «Дурак Онлайн» (36 карт):
              </h3>
              <ul className="list-disc pl-5 space-y-1 text-slate-300">
                <li>Каждому выдается по <strong>6 карт</strong>. Одна случайная определяется как <strong>Козырь</strong> (beat-all suit) и ложится снизу колоды.</li>
                <li><strong>Младший козырь</strong> на руках определяет того, кто будет первым нападать.</li>
                <li>Атакующий ходит любой картой. Защищающийся должен <strong>побить карту</strong>: картой той же масти, но старше по рангу, либо козырной картой. Козырь можно побить только старшим козырем.</li>
                <li>После атаки Нападающий может <strong>подбрасывать (подкидывать)</strong> карты того же достоинства (ранга), которые уже лежат на столе.</li>
                <li>Если защищающийся отбил все карты, нападающий объявляет <strong>«Бита»</strong> — карты уходят в отбой, а защищавшийся ходит следующим.</li>
                <li>Если защищающийся не может отбиться, он нажимает <strong>«Забрать»</strong> и забирает все карты. В таком случае следующий атакующий ход не меняется.</li>
                <li>В конце каждого раунда игроки добирают по очереди карты из колоды до 6. Победителем становится тот, у кого в руке <strong>не осталось карт</strong>, при пустой колоде.</li>
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CORE DISPLAY INNER LAYOUT */}
      <main className="flex-1 flex flex-col items-center justify-center p-3 sm:p-6 relative">
        {/* GAME SCREEN ROUTER */}
        {!roomId ? (
          /* SECTION 1: LANDING & JOIN/CREATE SCREEN */
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-black/45 backdrop-blur-2xl p-6 sm:p-8 rounded-3xl border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.7)] relative overflow-hidden z-10"
          >
            <div className="absolute -top-32 -left-32 h-64 w-64 rounded-full bg-emerald-500/5 blur-3xl"></div>
            <div className="absolute -bottom-32 -right-32 h-64 w-64 rounded-full bg-emerald-500/10 blur-3xl"></div>

            <div className="text-center mb-6 relative">
              <div className="mx-auto w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center font-mono text-3xl font-black text-slate-900 mb-3 shadow-[0_0_20px_rgba(16,185,129,0.4)]">
                Д
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase">Durak Online</h2>
              <p className="text-white/50 text-xs mt-1 leading-relaxed">Быстрые приватные игры в картишки подкидного дурака вместе на одном столе!</p>
            </div>

            {/* Error alerts */}
            {errorText && (
              <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={15} />
                <span>{errorText}</span>
              </div>
            )}

            {/* IDENTITY NAME FIELDS */}
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1.5">
                  Ваш игровой Никнейм:
                </label>
                <input
                  type="text"
                  maxLength={16}
                  placeholder="Супер Игрок..."
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/5 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-white font-medium outline-none transition-all placeholder:text-white/20 text-sm"
                />
              </div>

              {/* ACTION TOGGLER PANE */}
              <div className="flex gap-1.5 p-1 bg-black/40 rounded-xl border border-white/5">
                <button
                  type="button"
                  onClick={() => setIsJoinActive(false)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${!isJoinActive ? 'bg-emerald-500 text-slate-950 font-bold shadow-lg' : 'text-white/50 hover:text-white hover:bg-white/5'}`}
                >
                  Новая комната
                </button>
                <button
                  type="button"
                  onClick={() => setIsJoinActive(true)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${isJoinActive ? 'bg-emerald-500 text-slate-950 font-bold shadow-lg' : 'text-white/50 hover:text-white hover:bg-white/5'}`}
                >
                  Код подключения
                </button>
              </div>
            </div>

            {/* ACTION PANELS */}
            {!isJoinActive ? (
              <form onSubmit={handleCreateRoom} className="space-y-4">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-4 px-4 rounded-xl shadow-[0_8px_20px_rgba(16,185,129,0.3)] hover:shadow-[0_12px_28px_rgba(16,185,129,0.4)] transition-all duration-300 disabled:opacity-50 cursor-pointer uppercase tracking-widest text-[11px]"
                >
                  <span>Создать игровое лобби</span>
                  <Plus size={16} />
                </button>
              </form>
            ) : (
              <form onSubmit={handleJoinRoom} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1.5">
                    Код комнаты (5 символов):
                  </label>
                  <input
                    type="text"
                    maxLength={5}
                    placeholder="AX4BD"
                    value={roomInput}
                    onChange={(e) => setRoomInput(e.target.value.toUpperCase())}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/5 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-white font-mono text-center tracking-widest text-lg outline-none transition-all placeholder:text-white/10"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-4 px-4 rounded-xl shadow-[0_8px_20px_rgba(16,185,129,0.3)] hover:shadow-[0_12px_28px_rgba(16,185,129,0.4)] transition-all duration-300 disabled:opacity-50 cursor-pointer uppercase tracking-widest text-[11px]"
                >
                  <span>Присоединиться к дуэли</span>
                  <Users size={16} />
                </button>
              </form>
            )}

            <div className="mt-8 text-center text-[10px] text-white/30 border-t border-white/5 pt-4">
              Создайте лобби и скопируйте персональную ссылку для отправки другу через Telegram или ВКонтакте.
            </div>
          </motion.div>
        ) : !localRoom?.game ? (
          /* SECTION 2: LOBBY & WAITING SCREEN */
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full max-w-xl bg-black/60 backdrop-blur-2xl rounded-3xl border border-white/10 p-6 sm:p-8 shadow-[0_22px_60px_rgba(0,0,0,0.7)] relative overflow-hidden text-center z-10"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600"></div>

            <div className="mb-6">
              <span className="text-[10px] bg-emerald-950/80 text-emerald-400 border border-emerald-500/25 font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                Ожидание игроков
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white uppercase mt-3">Игровое лобби создано!</h2>
              <p className="text-xs text-white/50 mt-1">Осталось дождаться соперника и подтвердить готовность обеих сторон.</p>
            </div>

            {/* KEY LINK COPY SHARERS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center backdrop-blur-sm shadow-inner">
                <span className="text-[9px] text-white/40 uppercase tracking-widest font-bold">Код подключения</span>
                <span className="text-2xl font-mono font-black text-emerald-400 select-all tracking-widest my-1.5 drop-shadow-[0_0_12px_rgba(16,185,129,0.3)]">{roomId}</span>
                <button
                  onClick={copyRoomCode}
                  className="flex items-center gap-1.5 text-xs text-white bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg border border-white/5 transition-all shadow cursor-pointer mt-0.5"
                >
                  {copiedCode ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  <span>{copiedCode ? 'Скопировано!' : 'Копировать'}</span>
                </button>
              </div>

              <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center backdrop-blur-sm shadow-inner">
                <span className="text-[9px] text-white/40 uppercase tracking-widest font-bold font-bold">Прямая ссылка</span>
                <span className="text-xs font-mono text-white/50 truncate max-w-[150px] my-2 select-all">
                  {`/?room=${roomId}`}
                </span>
                <button
                  onClick={copyShareLink}
                  className="flex items-center gap-1.5 text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-3.5 py-1.5 rounded-lg transition duration-200 shadow-[0_4px_12px_rgba(16,185,129,0.25)] cursor-pointer mt-0.5 uppercase tracking-wider"
                >
                  {copiedLink ? <Check size={12} className="text-slate-950" /> : <Copy size={12} />}
                  <span>{copiedLink ? 'Гтово!' : 'Скопировать'}</span>
                </button>
              </div>
            </div>

            {/* CONNECTED PLAYERS LIST */}
            <div className="bg-black/40 border border-white/5 rounded-2xl p-4 sm:p-5 mb-6 text-left">
              <h4 className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-3">
                Присоединились ({localRoom?.players.length}/2):
              </h4>

              <div className="space-y-2">
                {localRoom?.players.map((p) => (
                  <div 
                    key={p.id} 
                    className="flex justify-between items-center p-3.5 rounded-xl border border-white/5 bg-white/[0.02]"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></div>
                      <span className="font-bold text-sm text-white flex items-center gap-1">
                        {p.name}
                        {p.id === playerId && <span className="text-[10px] text-white/40 font-normal italic">(вы)</span>}
                      </span>
                    </div>

                    <span 
                      className={`text-[10.5px] px-3 py-1 rounded-full font-bold border uppercase tracking-wider ${p.isReady ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-amber-500/10 border-amber-500/20 text-amber-400'}`}
                    >
                      {p.isReady ? '✓ Готов' : 'Ожидание'}
                    </span>
                  </div>
                ))}

                {localRoom && localRoom.players.length < 2 && (
                  <div className="flex items-center justify-center p-6 border border-dashed border-white/10 rounded-xl text-white/40 text-xs gap-2.5 animate-pulse bg-white/[0.01]">
                    <Users size={16} />
                    <span>Ожидание соперника... Перешлите код {roomId} другу</span>
                  </div>
                )}
              </div>
            </div>

            {/* READY UP ACTION BUTTON */}
            {localRoom && (
              <button
                onClick={handleReadyToggle}
                className={`w-full py-4 rounded-xl text-xs font-black tracking-widest shadow-lg border cursor-pointer transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 uppercase ${
                  me?.isReady 
                    ? 'bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30 text-amber-400' 
                    : 'bg-emerald-500 hover:bg-emerald-400 border-emerald-500/20 text-slate-950 shadow-[0_10px_25px_rgba(16,185,129,0.3)] hover:shadow-[0_14px_30px_rgba(16,185,129,0.4)]'
                }`}
              >
                {me?.isReady ? '✖ Отменить готовность' : '✔ Подтвердить Готовность!'}
              </button>
            )}

            <p className="text-[10px] text-white/30 italic mt-3.5 leading-relaxed">
              Карты будут розданы случайным образом как только оба игрока нажмут кнопку «Готов к бою».
            </p>
          </motion.div>
        ) : (
          /* SECTION 3: IMMERSIVE ACTIVE DUEL CARD FELT TABLE */
          <div className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-4 gap-6 items-stretch relative">
            
            {/* LEFT / CENTRAL AREA: THE FELT TABLE AND CONTROLS (3 cols) */}
            <div className="lg:col-span-3 flex flex-col justify-between items-center bg-gradient-to-b from-[#11321f]/50 to-[#06140d]/75 backdrop-blur-xl p-3 sm:p-6 rounded-3xl border border-emerald-500/10 shadow-[0_25px_50px_rgba(0,0,0,0.6),_inset_0_2px_40px_rgba(16,185,129,0.05)] min-h-[600px] sm:min-h-[680px] relative z-10">
              {/* Felt inner borders and atmosphere */}
              <div className="absolute inset-3 border border-emerald-500/10 rounded-2xl pointer-events-none"></div>

              {/* TABLE BOARD TOP ROW: OPPONENT INFORMATION PANEL */}
              <div className="w-full flex justify-between items-center bg-black/45 border border-white/5 p-3 rounded-2xl backdrop-blur-sm z-10">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="h-9 w-9 rounded-full bg-emerald-950 flex items-center justify-center font-bold text-emerald-400 border border-emerald-500/20">
                      {companion?.name ? companion.name.charAt(0).toUpperCase() : 'С'}
                    </div>
                    {companion?.isOnline ? (
                      <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-500 border-2 border-[#092215]"></div>
                    ) : (
                      <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-slate-500 border-2 border-[#092215] animate-pulse"></div>
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                      {companion?.name || 'Ожидающий соперник...'}
                      {game?.defenderId === companion?.id && (
                        <span className="text-[9px] bg-sky-950 text-sky-400 border border-sky-450/20 px-2 py-0.5 rounded-full font-mono font-bold uppercase select-none">
                          Защита
                        </span>
                      )}
                      {game?.attackerId === companion?.id && (
                        <span className="text-[9px] bg-rose-950 text-rose-450 border border-rose-400/20 px-2 py-0.5 rounded-full font-mono font-bold uppercase select-none">
                          Атакует
                        </span>
                      )}
                    </h4>
                    <p className="text-[10px] text-white/50 font-medium">У соперника: {companion?.cardsCount || 0} карт</p>
                  </div>
                </div>

                {/* Companion's Card Silhouette list - Curved layout */}
                <div className="flex gap-1.5 overflow-x-auto max-w-[50%] pr-2 h-14 items-center">
                  {Array.from({ length: companion?.cardsCount || 0 }).map((_, i) => (
                    <div 
                      key={i} 
                      className="w-7 h-10 sm:w-8 sm:h-12 bg-gradient-to-br from-[#123e27]/80 to-[#071a10]/95 border border-white/10 rounded-lg flex items-center justify-center select-none shadow-[0_4px_8px_rgba(0,0,0,0.3)] transition-transform origin-bottom"
                      style={{ 
                        transform: `rotate(${(i - ((companion?.cardsCount || 1) - 1) / 2) * 4}deg) translateY(${Math.abs(i - ((companion?.cardsCount || 1) - 1) / 2) * 1.5}px)` 
                       }}
                    >
                      <div className="text-[8px] sm:text-[10px] text-emerald-500/20 font-mono">♣</div>
                    </div>
                  ))}
                </div>
              </div>


              {/* TABLE BOARD MIDDLE ROW: THE DECK STACK AND THE DISCARD PILE AND TRUMP AND ACTION FELT */}
              <div className="w-full my-4 grid grid-cols-1 md:grid-cols-4 gap-4 items-center flex-1 z-10">
                
                {/* 1. LEFT CARD BLOCK: DECK PILE AND TRUMP DISPLAY */}
                <div className="md:col-span-1 flex flex-row md:flex-col items-center justify-center gap-4 bg-black/20 border border-white/5 p-4 rounded-2xl">
                  
                  {/* DRAW PILE WITH POPPED TRUMP IN 3D ANGLE */}
                  <div className="relative w-28 h-40 flex items-center justify-center">
                    {/* Popped trump card tilted 90 degrees under the deck */}
                    {game?.trumpCard ? (
                      <div className="absolute inset-0 flex items-center justify-center rotate-90 z-0">
                        <CardUnit card={game.trumpCard} size="sm" isTrump={true} isTableCard={true} />
                      </div>
                    ) : (
                      game?.trumpSuit && (
                        <div className="absolute h-14 w-10 border border-dashed border-white/10 rounded flex items-center justify-center text-white/20 font-bold opacity-30">
                          {suitIcons[game.trumpSuit]}
                        </div>
                      )
                    )}

                    {/* Deck pile stacked over top of the trump */}
                    {game && game.deckCount > 0 ? (
                      <div className="absolute inset-0 flex items-center justify-center z-10">
                        <CardUnit size="sm" />
                        <span className="absolute bg-[#0b281b]/95 text-emerald-400 border border-emerald-500/30 font-mono font-bold text-[10px] sm:text-xs px-2 py-0.5 rounded-full shadow-[0_4px_12px_rgba(0,0,0,0.5)] z-20">
                          {game.deckCount} шт
                        </span>
                      </div>
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center z-10 bg-black/45 w-16 h-24 border border-dashed border-white/15 rounded-xl text-white/25 font-mono text-[9px] font-bold text-center leading-relaxed">
                        Колода<br/>разобрана
                      </div>
                    )}
                  </div>

                  {/* MINI METADATA */}
                  <div className="text-center md:text-left">
                    <span className="block text-[9px] uppercase font-bold text-white/40 tracking-wider">Козырная масть</span>
                    <span className="font-extrabold text-lg text-amber-400 mt-1 flex items-center gap-1.5 md:justify-start justify-center">
                      <span className="text-2xl leading-none">
                        {game?.trumpSuit ? suitIcons[game.trumpSuit] : ''}
                      </span>
                      <span>{game?.trumpSuit ? suitNamesRu[game.trumpSuit].split(' ')[0] : 'Нет'}</span>
                    </span>
                    <span className="block text-[9px] text-white/40 mt-1">Отбой: {game?.discardPileCount || 0} карт</span>
                  </div>
                </div>

                {/* 2. CENTER AREA: CARDS LAID IN DUEL COMBAT (Attack and defense pairs) */}
                <div className="md:col-span-3 min-h-[200px] sm:min-h-[260px] bg-white/[0.015] border border-white/5 rounded-[120px] p-6 flex flex-wrap gap-x-6 gap-y-8 items-center justify-center relative shadow-[inset_0_4px_30px_rgba(0,0,0,0.6)]">
                  {/* Subtle Central Arena Text Backdrop */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
                    <div className="text-white/[0.02] text-5xl sm:text-7xl font-serif italic tracking-[1.5em] uppercase translate-x-[0.75em]">
                      БИТО
                    </div>
                  </div>
                  
                  {game?.table && game.table.length > 0 ? (
                    game.table.map((pair) => (
                      <div key={pair.id} className="relative w-18 h-28 sm:w-22 sm:h-32 m-2">
                        
                        {/* ATTACK CARD */}
                        <div className="absolute top-0 left-0 z-10 shadow-[0_4px_12px_rgba(0,0,0,0.3)] hover:z-20 transition-all">
                          <CardUnit 
                            card={pair.attackCard} 
                            size="md" 
                            isTrump={pair.attackCard.suit === game.trumpSuit}
                            isTableCard={true}
                          />
                        </div>

                        {/* DEFENSE CARD (Beaten overlap) */}
                        {pair.defenseCard ? (
                          <div className="absolute top-4 left-4 z-15 transform rotate-6 shadow-[0_6px_18px_rgba(0,0,0,0.4)]">
                            <CardUnit 
                              card={pair.defenseCard} 
                              size="md" 
                              isTrump={pair.defenseCard.suit === game.trumpSuit}
                              isTableCard={true}
                            />
                          </div>
                        ) : (
                          // If not beaten and player is defender, show a tactical blinking cover prompt
                          isMyDefending && (
                            <button
                              onClick={() => handleTablePairClick(pair)}
                              className={`absolute -top-1 -right-1 z-30 h-8 w-8 sm:h-9 sm:w-9 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 hover:scale-105 active:scale-95 flex items-center justify-center font-black text-[10px] shadow-[0_4px_15px_rgba(16,185,129,0.5)] animate-pulse cursor-pointer border-2 border-white`}
                              title="Кликните сюда, выбрав карту"
                            >
                              БИТЬ
                            </button>
                          )
                        )}
                        
                        {/* Visual identification of card pairings */}
                        <span className="absolute bottom-[-18px] left-0 right-0 text-center text-[10px] font-semibold text-emerald-400/70 pointer-events-none">
                          {pair.defenseCard ? '✓ Побито' : '⚠ Открыто'}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-white/30 text-xs py-10 flex flex-col items-center justify-center relative">
                      <div className="rounded-full bg-emerald-950/40 p-4.5 border border-emerald-500/10 mb-3 text-2xl shadow-inner animate-pulse">
                        🎴
                      </div>
                      <p className="font-bold text-white/60 uppercase tracking-widest text-[11px]">Игровое сукно пусто</p>
                      <p className="text-[10px] text-white/40 mt-1 max-w-[220px] leading-relaxed">
                        {isMyTurn ? 'Сделайте наступательный ход любой из своих карт!' : 'Ожидайте розыгрыша карт от вашего соперника.'}
                      </p>
                    </div>
                  )}
                </div>

              </div>


              {/* TABLE BOARD CONTROLS ZONE: VALIDATORS AND FEEDBACK */}
              {gameErrorMessage && (
                <div className="w-full mb-3 p-2 bg-amber-500/15 border border-amber-500/25 text-amber-300 text-xs text-center rounded-xl shadow-lg font-medium flex items-center justify-center gap-1.5 animate-pulse z-10">
                  <AlertTriangle size={14} />
                  <span>{gameErrorMessage}</span>
                </div>
              )}

              {/* ACTION COMMANDERS */}
              <div className="w-full bg-black/45 border border-white/5 p-4 rounded-2xl mb-4 flex flex-col sm:flex-row gap-3 items-center justify-between backdrop-blur-sm z-10">
                
                {/* Active Player description roles */}
                <div>
                  {isMyTurn ? (
                    <div className="text-left">
                      <span className="text-[10px] bg-emerald-500 text-slate-950 font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Ваш ход! (Атака)
                      </span>
                      <p className="text-xs text-white/60 mt-1.5">
                        {game?.table.length === 0 
                          ? 'Сделайте атакующий ход любой доступной картой.' 
                          : 'Вы можете подкинуть карты такого же достоинства, как на столе.'}
                      </p>
                    </div>
                  ) : isMyDefending ? (
                    <div className="text-left">
                      <span className="text-[10px] bg-sky-500 text-slate-950 font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Вы защищаетесь!
                      </span>
                      <p className="text-xs text-white/60 mt-1.5 leading-relaxed">
                        {selectedMyCardId 
                          ? 'Кликните на желтую кнопку «БИТЬ» над картой стола, чтобы покрыть её.' 
                          : 'Выберите карту в веере ниже, а затем укажите цель на сукне.'}
                      </p>
                    </div>
                  ) : (
                    <div className="text-left">
                      <span className="text-[9px] bg-white/10 text-white/50 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-widest">
                        Ожидание хода...
                      </span>
                      <p className="text-xs text-white/40 mt-1.5">
                        Сейчас ходит {attackerName} против {defenderName}.
                      </p>
                    </div>
                  )}
                </div>

                {/* Tactical Actions Buttons */}
                <div className="flex gap-2.5">
                  {isMyTurn && (
                    <button
                      onClick={() => submitGameAction('pass')}
                      disabled={game?.table.length === 0 || !game?.table.every(p => p.defenseCard)}
                      className={`px-6 py-3 rounded-xl text-[11px] font-black tracking-widest shadow border transition-all cursor-pointer uppercase ${
                        game?.table.length > 0 && game?.table.every(p => p.defenseCard)
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400 hover:bg-emerald-400 shadow-[0_4px_12px_rgba(16,185,129,0.35)]'
                          : 'bg-white/5 text-white/30 border-white/5 opacity-40 cursor-not-allowed'
                      }`}
                      title="Отправить в биту, если соперник покрыл все карты"
                    >
                      БИТА (ПАС)
                    </button>
                  )}

                  {isMyDefending && (
                    <button
                      onClick={() => submitGameAction('take')}
                      disabled={game?.table.length === 0}
                      className={`px-6 py-3 rounded-xl text-[11px] font-black tracking-widest shadow border transition-all cursor-pointer uppercase ${
                        game?.table.length > 0
                          ? 'bg-rose-600 hover:bg-rose-500 border-rose-500 text-white shadow-[0_4px_12px_rgba(225,29,72,0.35)]'
                          : 'bg-white/5 text-white/30 border-white/5 opacity-40 cursor-not-allowed'
                      }`}
                      title="Забрать все карты себе, если нет возможности отбиться"
                    >
                      ЗАБРАТЬ КАРТЫ
                    </button>
                  )}
                </div>
              </div>


              {/* TABLE BOARD BOTTOM ROW: PLAYER HAND веер */}
              <div className="w-full mt-2 bg-black/45 border border-white/5 p-4 rounded-2xl relative z-10">
                <div className="flex justify-between items-center mb-3 px-1">
                  <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                    Ваша рука ({me?.cardsCount || 0} карт):
                  </span>
                  {selectedMyCardId && (
                    <button
                      onClick={() => setSelectedMyCardId(null)}
                      className="text-[10px] text-rose-400 hover:text-rose-300 transition-all font-semibold cursor-pointer"
                    >
                      Сбросить выбор
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap justify-center gap-2 py-4 px-1 min-h-[145px] items-end overflow-visible">
                  {me?.hand && me.hand.length > 0 ? (
                    me.hand
                      .sort((a, b) => {
                        const aTrump = a.suit === game?.trumpSuit;
                        const bTrump = b.suit === game?.trumpSuit;
                        if (aTrump && !bTrump) return 1;
                        if (!aTrump && bTrump) return -1;
                        return a.rank - b.rank;
                      })
                      .map((card, idx, arr) => {
                        const isTrump = card.suit === game?.trumpSuit;
                        const isSelected = selectedMyCardId === card.id;

                        // Calculate if this card can legally defend/attack to help user
                        let isCardDisabled = false;
                        if (isMyTurn && game && game.table.length > 0) {
                          const tableRanks = new Set<CardValue>();
                          for (const pair of game.table) {
                            tableRanks.add(pair.attackCard.value);
                            if (pair.defenseCard) tableRanks.add(pair.defenseCard.value);
                          }
                          isCardDisabled = !tableRanks.has(card.value);
                        }

                        // Curvaceous card fan projection calculations
                        const totalCards = arr.length;
                        const middle = (totalCards - 1) / 2;
                        const rot = (idx - middle) * (totalCards > 10 ? 3 : 4);
                        const transY = Math.abs(idx - middle) * (totalCards > 10 ? 2 : 3);

                        return (
                          <div 
                            key={card.id} 
                            className="transition-transform duration-300 ease-out origin-bottom hover:z-30"
                            style={{ 
                              transform: `rotate(${rot}deg) translateY(${transY}px)` 
                            }}
                          >
                            <CardUnit
                              card={card}
                              size="md"
                              isTrump={isTrump}
                              isSelected={isSelected}
                              isDisabled={isCardDisabled}
                              onClick={() => handleMyCardClick(card, isMyTurn)}
                            />
                          </div>
                        );
                      })
                  ) : (
                    <span className="text-xs text-white/40 italic py-6">В вашей руке нет карт</span>
                  )}
                </div>
              </div>

            </div>


            {/* RIGHT SIDE AREA: CONVERSATION PANEL & SOCIAL ACTIONS (1 col) */}
            <div className="lg:col-span-1 flex flex-col justify-between bg-black/45 backdrop-blur-md rounded-3xl border border-white/5 shadow-2xl p-4 overflow-hidden h-[600px] sm:h-[680px]">
              
              {/* CHAT MESSAGES PANEL */}
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-3 shrink-0">
                  <MessageSquare size={16} className="text-emerald-400" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white/75">Чат и Логи игры</h3>
                </div>

                {/* Scroll messages window */}
                <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 mb-3 scrollbar-none text-[11px] sm:text-xs">
                  {localRoom?.chat.map((msg) => {
                    if (msg.isSystem) {
                      return (
                        <div 
                          key={msg.id} 
                          className="p-2.5 py-2 bg-emerald-950/20 border-l-2 border-emerald-500/50 text-emerald-300 italic rounded-r-xl leading-relaxed text-[10px]"
                        >
                          {msg.text}
                        </div>
                      );
                    }

                    const isFromMe = msg.senderId === playerId;
                    return (
                      <div 
                        key={msg.id} 
                        className={`flex flex-col max-w-[85%] ${isFromMe ? 'ml-auto items-end' : 'mr-auto items-start'}`}
                      >
                        <span className="text-[9px] text-white/40 font-bold mb-0.5">{msg.senderName}</span>
                        <div 
                          className={`p-2.5 rounded-2xl leading-relaxed break-words text-white ${
                            isFromMe 
                              ? 'bg-emerald-600 rounded-tr-none' 
                              : 'bg-white/10 rounded-tl-none border border-white/5'
                          }`}
                        >
                          {msg.text}
                        </div>
                      </div>
                    );
                  })}
                  <div ref={chatEndRef} />
                </div>
              </div>

              {/* QUICK PHRASE EMOTES PANEL */}
              <div className="border-t border-white/10 pt-3 mb-3 shrink-0">
                <span className="block text-[9px] uppercase font-bold text-white/40 tracking-wider mb-2">Фразы для друга:</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {QUICK_PHRASES.map((phrase, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendChatMessage(phrase)}
                      className="py-1.5 px-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-left text-[10px] sm:text-[10.5px] truncate font-medium text-white/80 cursor-pointer transition-all hover:translate-x-0.5 active:translate-x-0"
                    >
                      {phrase}
                    </button>
                  ))}
                </div>
              </div>

              {/* MESSAGE CUSTOM INPUT */}
              <div className="border-t border-white/10 pt-3 shrink-0">
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendChatMessage(chatText);
                  }}
                  className="flex gap-1.5"
                >
                  <input
                    type="text"
                    maxLength={100}
                    placeholder="Написать другу..."
                    value={chatText}
                    onChange={(e) => setChatText(e.target.value)}
                    className="flex-1 px-3.5 py-2 text-xs bg-black/40 border border-white/10 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-white font-medium outline-none transition-all placeholder:text-white/30"
                  />
                  <button
                    type="submit"
                    className="p-2 sm:p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center transition-all cursor-pointer shadow-lg hover:shadow-[0_4px_12px_rgba(16,185,129,0.3)] active:scale-95 shrink-0"
                  >
                    <Send size={14} />
                  </button>
                </form>
              </div>

            </div>

          </div>
        )}
      </main>

      {/* GAME OVER MODAL OVERLAYS */}
      <AnimatePresence>
        {game?.status === 'finished' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#040c08]/95 z-50 flex items-center justify-center p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 10 }}
              className="w-full max-w-md bg-gradient-to-b from-[#11321f] to-[#06140d] border border-emerald-500/20 rounded-3xl p-6 sm:p-8 text-center shadow-2xl relative overflow-hidden"
            >
              <div className="absolute -top-16 -left-16 h-32 w-32 rounded-full bg-emerald-500/10 blur-2xl"></div>

              <div className="mx-auto w-16 h-16 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20 mb-4 animate-bounce">
                <Trophy size={36} />
              </div>

              <h2 className="text-2xl font-black text-white tracking-tight uppercase">
                {game.isDraw ? 'Ничья!' : game.winnerId === playerId ? 'Победа! 🎉' : 'Остались в дураках... 🤪'}
              </h2>

              <p className="text-white/70 text-sm mt-3 leading-relaxed">
                {game.lastActionMessage}
              </p>

              <div className="bg-black/45 rounded-2xl p-4 border border-white/5 my-5 text-xs space-y-1.5 text-left">
                <span className="block text-white/40 font-bold uppercase tracking-widest text-[8px] mb-2 text-center">Статистика дуэли</span>
                <p className="text-white/60 flex justify-between">Атакующий: <strong className="text-white">{attackerName}</strong></p>
                <p className="text-white/60 flex justify-between">Защищающийся: <strong className="text-white">{defenderName}</strong></p>
                {game.loserId && (
                  <p className="text-rose-400 font-bold flex justify-between mt-2 pt-2 border-t border-white/5">
                    <span>Под куполом (Дурак):</span> 
                    <span>{localRoom?.players.find(p => p.id === game.loserId)?.name}</span>
                  </p>
                )}
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleReadyToggle}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-3.5 px-4 rounded-xl shadow-lg shadow-emerald-500/25 border border-emerald-500/10 transition-all cursor-pointer uppercase text-xs tracking-wider"
                >
                  Реванш! (Готов)
                </button>
                <button
                  onClick={() => handleLeave(true)}
                  className="flex-grow bg-white/5 hover:bg-white/10 text-white/70 hover:text-white font-semibold py-3.5 px-4 rounded-xl border border-white/5 transition-all cursor-pointer text-xs"
                >
                  Выйти
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FOOTER METADATA */}
      <footer className="border-t border-white/5 bg-black/40 p-4 text-center text-xs text-white/40">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-3 font-medium">
          <span>© 2026 Игровой портал Дурак Онлайн. Все права защищены.</span>
          <span className="font-mono text-[10px] text-emerald-500/50">Rules: Classic russian Durak (Подкидной дурак).</span>
        </div>
      </footer>
    </div>
  );
}
