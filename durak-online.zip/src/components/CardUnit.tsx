/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Card, CardSuit } from '../types.js';

interface CardUnitProps {
  card?: Card; // If undefined, render card back
  isTrump?: boolean;
  isSelected?: boolean;
  isDisabled?: boolean;
  isTableCard?: boolean;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export default function CardUnit({
  card,
  isTrump = false,
  isSelected = false,
  isDisabled = false,
  isTableCard = false,
  onClick,
  size = 'md'
}: CardUnitProps) {
  
  const suitIcons: Record<CardSuit, string> = {
    H: '♥', // Hearts
    D: '♦', // Diamonds
    C: '♣', // Clubs
    S: '♠'  // Spades
  };

  const suitNamesRu: Record<CardSuit, string> = {
    H: 'Черви',
    D: 'Бубны',
    C: 'Трефы',
    S: 'Пики'
  };

  const isRed = card?.suit === 'H' || card?.suit === 'D';
  const suitIcon = card ? suitIcons[card.suit] : '';

  // Size configurations
  let sizeClasses = 'w-16 h-24 text-sm rounded-lg'; // sm
  if (size === 'md') {
    sizeClasses = 'w-24 h-36 text-lg rounded-xl';
  } else if (size === 'lg') {
    sizeClasses = 'w-28 h-40 text-xl rounded-2xl';
  }

  // Card Back style
  if (!card) {
    return (
      <div
        id="card-back"
        onClick={onClick}
        className={`${sizeClasses} bg-gradient-to-br from-[#154734] via-[#092215] to-[#04110b] border border-white/15 shadow-[0_10px_20px_rgba(0,0,0,0.5)] relative overflow-hidden flex items-center justify-center cursor-pointer transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-[0_0_20px_rgba(16,185,129,0.3)]`}
      >
        {/* Ornate Card Back Pattern */}
        <div className="absolute inset-1 border border-emerald-500/25 rounded-lg flex items-center justify-center bg-black/45">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '12px 12px' }} />
          {/* Central Logo and lines */}
          <div className="absolute inset-2 border border-dashed border-emerald-500/10 rounded-md"></div>
          <div className="absolute font-mono text-emerald-400/40 text-xs sm:text-sm tracking-widest font-black select-none text-center leading-relaxed">
            DURAK
            <div className="text-[10px] opacity-60">♠♦♣♥</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      id={`card-${card.id}`}
      onClick={isDisabled ? undefined : onClick}
      className={`
        ${sizeClasses}
        relative bg-white select-none shadow-[0_8px_24px_rgba(0,0,0,0.35)] border flex flex-col justify-between p-3.5 cursor-pointer transition-all duration-300 transform
        ${isSelected ? 'ring-4 ring-emerald-500/80 -translate-y-5 scale-105 shadow-[0_15px_30px_rgba(16,185,129,0.4)] z-50' : ''}
        ${isDisabled ? 'opacity-35 cursor-not-allowed contrast-75 saturate-50' : 'hover:-translate-y-3.5 hover:shadow-2xl hover:border-emerald-500/35'}
        ${isRed ? 'text-rose-600' : 'text-slate-950'}
        ${isTrump ? 'border-amber-400 bg-amber-50/15 ring-2 ring-amber-400/20' : 'border-slate-100'}
      `}
    >
      {/* Top Left Indicator */}
      <div className="flex flex-col items-center justify-start leading-none text-left self-start">
        <span className="font-sans font-bold tracking-tighter" style={{ fontSize: size === 'sm' ? '0.75rem' : '1.1rem' }}>
          {card.value}
        </span>
        <span className="-mt-0.5 text-base" style={{ fontSize: size === 'sm' ? '0.75rem' : '1.1rem' }}>{suitIcon}</span>
      </div>

      {/* Large Center Suit Visual */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
        <span 
          className="opacity-15 font-sans leading-none" 
          style={{ 
            fontSize: size === 'sm' ? '1.8rem' : size === 'md' ? '3.2rem' : '4rem',
            transform: 'scaleY(1.05)'
          }}
        >
          {suitIcon}
        </span>
      </div>

      {/* Bottom Right Indicator */}
      <div className="flex flex-col items-center justify-end leading-none text-right self-end rotate-180">
        <span className="font-sans font-bold tracking-tighter" style={{ fontSize: size === 'sm' ? '0.75rem' : '1.1rem' }}>
          {card.value}
        </span>
        <span className="-mt-0.5 text-base" style={{ fontSize: size === 'sm' ? '0.75rem' : '1.1rem' }}>{suitIcon}</span>
      </div>

      {/* Trump Badge Overlay */}
      {isTrump && !isTableCard && (
        <span className="absolute bottom-1 left-1.5 text-[8px] bg-amber-400 text-slate-950 font-bold px-1 py-0.2 rounded-sm select-none uppercase tracking-wide">
          Козырь
        </span>
      )}
    </div>
  );
}
