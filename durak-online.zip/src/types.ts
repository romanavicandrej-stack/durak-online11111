/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CardSuit = 'H' | 'D' | 'C' | 'S'; // Hearts, Diamonds, Clubs, Spades
export type CardValue = '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  id: string; // e.g., "H_6"
  suit: CardSuit;
  value: CardValue;
  rank: number; // 6 to 14
}

export interface Player {
  id: string;
  name: string;
  isReady: boolean;
  cardsCount: number;
  hand?: Card[]; // Excluded or masked for other players
  isOnline: boolean;
}

export interface TablePair {
  id: string; // ID of the attack card (or generated)
  attackCard: Card;
  defenseCard?: Card;
}

export type GameStatus = 'waiting' | 'playing' | 'finished';

export interface GameState {
  status: GameStatus;
  deckCount: number;
  trumpCard: Card | null;
  trumpSuit: CardSuit | null;
  attackerId: string | null;
  defenderId: string | null;
  table: TablePair[];
  discardPileCount: number;
  winnerId: string | null;
  loserId: string | null;
  isDraw: boolean;
  lastActionMessage: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
  isSystem?: boolean;
}

export interface Room {
  id: string;
  players: Player[];
  game: GameState | null;
  chat: ChatMessage[];
  createdAt: number;
}
